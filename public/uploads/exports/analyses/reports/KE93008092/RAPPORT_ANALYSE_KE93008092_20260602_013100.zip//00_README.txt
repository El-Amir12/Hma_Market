========================================
EXPORT BRUT DES DONNEES
========================================

Entreprise: Zitawi
N° Abonnement: KE93008092
Type: Restaurant
Période analysée: 25/03/2026 au 25/05/2026
Type d'analyse: Analyse Power BI
Date d'export: 01/06/2026 20:14:57

--- STRUCTURE DU DOSSIER ---

📁 01_ENTREPRISE_INFO/ - Informations générales
📁 02_ACHATS/ - Approvisionnement et fournisseurs
📁 03_VENTES/ - Commandes clients et retours
📁 04_STOCK/ - Lots, mouvements et inventaires
📁 05_PRODUITS/ - Catalogue, catégories, recettes et promotions
📁 06_UTILISATEURS/ - Personnel et rôles

--- COMMENT ANALYSER CES DONNEES ---

Ces fichiers contiennent toutes les données brutes.
Le rapport final sera fourni séparément par nos experts.

--- SUPPORT ---

Pour toute question, contactez le support: support@hma-market.com
