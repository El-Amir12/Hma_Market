========================================
EXPORT BRUT DES DONNEES
========================================

Entreprise: Zitawi
N° Abonnement: KE93008092
Type: Restaurant
Période analysée: 20/03/2026 au 03/06/2026
Type d'analyse: Analyse Standard
Date d'export: 05/06/2026 22:36:42

--- STRUCTURE DU DOSSIER ---

📁 01_ENTREPRISE_INFO/ - Informations générales
📁 02_ACHATS/ - Approvisionnement et fournisseurs
📁 03_VENTES/ - Commandes clients et retours
📁 04_STOCK/ - Lots, mouvements et inventaires
📁 05_PRODUITS/ - Catalogue, catégories, recettes et promotions
📁 06_UTILISATEURS/ - Personnel et rôles

--- COMMENT ANALYSER CES DONNEES ---

Ces fichiers contiennent toutes les données brutes.
Le rapport final sera fourni séparément par nos experts.

--- SUPPORT ---

Pour toute question, contactez le support: support@hma-market.com
