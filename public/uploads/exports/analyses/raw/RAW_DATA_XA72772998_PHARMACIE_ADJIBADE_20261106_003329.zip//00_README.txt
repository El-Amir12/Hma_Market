========================================
EXPORT BRUT DES DONNEES
========================================

Entreprise: Pharmacie Adjibade
N° Abonnement: XA72772998
Type: Commerce de détail
Période analysée: 01/10/2026 au 30/10/2026
Type d'analyse: Analyse Standard
Date d'export: 06/11/2026 00:33:30

--- STRUCTURE DU DOSSIER ---

📁 01_ENTREPRISE_INFO/ - Informations générales
📁 02_ACHATS/ - Approvisionnement et fournisseurs
📁 03_VENTES/ - Commandes clients et retours
📁 04_STOCK/ - Lots, mouvements et inventaires
📁 05_PRODUITS/ - Catalogue, catégories, recettes et promotions
📁 06_UTILISATEURS/ - Personnel et rôles

--- COMMENT ANALYSER CES DONNEES ---

Ces fichiers contiennent toutes les données brutes.
Le rapport final sera fourni séparément par nos experts.

--- SUPPORT ---

Pour toute question, contactez le support: support@hma-market.com
